<?php
$serverName ="localhost";
$userName ="root";
$password ="";
$dbname ="project";

$conn = mysqli_connect($serverName,$userName,$password,$dbname);
?>